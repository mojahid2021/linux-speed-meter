#include "systemtray.h"
#include "speed_monitor_qt.h"
#include <QApplication>
#include <QAction>
#include <QDebug>

SystemTray::SystemTray(SpeedMonitor* monitor, QObject* parent)
    : QSystemTrayIcon(parent)
    , speedMonitor_(monitor)
    , contextMenu_(nullptr)
    , updateTimer_(new QTimer(this))
{
    // Create context menu
    createContextMenu();

    // Set initial icon and tooltip
    normalIcon_ = QIcon(":/icons/network-idle.png");
    activeIcon_ = QIcon(":/icons/network-active.png");

    setIcon(normalIcon_);
    setToolTip("Linux Speed Meter - Initializing...");

    // Connect signals
    connect(this, &QSystemTrayIcon::activated, this, &SystemTray::onActivated);
    connect(updateTimer_, &QTimer::timeout, this, &SystemTray::updateTrayInfo);

    // Start update timer (update every second)
    updateTimer_->start(1000);

    // Initial update
    updateTrayInfo();
}

SystemTray::~SystemTray() {
    if (updateTimer_) {
        updateTimer_->stop();
    }
}

void SystemTray::createContextMenu() {
    contextMenu_ = new QMenu();

    QAction* showAction = contextMenu_->addAction("Show Speed Meter");
    connect(showAction, &QAction::triggered, this, &SystemTray::onShowMainWindow);

    contextMenu_->addSeparator();

    QAction* quitAction = contextMenu_->addAction("Quit");
    connect(quitAction, &QAction::triggered, this, &SystemTray::onQuit);

    setContextMenu(contextMenu_);
}

void SystemTray::updateTrayInfo() {
    if (!speedMonitor_) {
        return;
    }

    updateIconAndTooltip();
}

void SystemTray::updateIconAndTooltip() {
    if (!speedMonitor_) {
        setToolTip("Linux Speed Meter - No data");
        return;
    }

    QString label = speedMonitor_->getLabel();
    QString tooltip = speedMonitor_->getTooltip();

    setToolTip(tooltip);

    // Update icon based on activity
    bool isActive = speedMonitor_->isActive();
    setIcon(isActive ? activeIcon_ : normalIcon_);
}

void SystemTray::onActivated(QSystemTrayIcon::ActivationReason reason) {
    switch (reason) {
        case QSystemTrayIcon::DoubleClick:
        case QSystemTrayIcon::Trigger:
            emit showMainWindow();
            break;
        default:
            break;
    }
}

void SystemTray::onShowMainWindow() {
    emit showMainWindow();
}

void SystemTray::onQuit() {
    QApplication::quit();
}