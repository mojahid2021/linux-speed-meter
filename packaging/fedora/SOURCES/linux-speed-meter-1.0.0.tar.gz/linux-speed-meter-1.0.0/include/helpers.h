#ifndef HELPERS_H
#define HELPERS_H

#include <string>

std::string formatSpeed(double speed);
std::string formatDataUsage(long long bytes);

#endif // HELPERS_H
